// Basic JavaScript file structure

const form = document.getElementById("loginform");
form.addEventListener("submit", function (e) {
  e.preventDefault();
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  if (username === "" || password === "") {
    alert("Please fill the form");
  } else {
    coonsole.log("username: ", username);
    console.log("password: ", password);
    alert("Login successful");
  }
});
